package starter.navigations;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("C://Users//sarha//Downloads/export.pdf")
public class Downloads extends PageObject {
}
