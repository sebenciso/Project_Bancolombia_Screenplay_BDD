package starter.navigations;

import net.thucydides.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.bancolombia.com/personas")
public class BancolombiaHomePage extends PageObject {

}



