package starter.stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import starter.questions.ValidarInformacionCreditoVehiculo;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;

public class SaberMas {

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }

    @When("^Ingresa a SABER MÁS$")
    public void searchSABERMAS() {
        theActorInTheSpotlight().attemptsTo(

        );
    }

    @Then("^Se visualice solo SABER MÁS$")
    public void ShouldSeeOnlyLast4DigitsCTC() {
        String EXPECTED_SABER_MAS = "SABER MÁS";

        theActorInTheSpotlight().should(
                seeThat("SABER MÁS", new ValidarInformacionCreditoVehiculoQuestions.titleFinanzasTusSuenos(), equalTo(EXPECTED_SABER_MAS))
        );
    }

}
