package starter.navigations;

import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.actions.Open;

import static net.serenitybdd.screenplay.Task.where;

public class NavigateTo {

    public static Performable BancolombiaHomePage() {
        return where("{0} opens the BancolombiaPersonas home page",
                Open.browserOn().the(BancolombiaHomePage.class));
    }
    public static Performable Descarga() {
        return where("{0} opens the BancolombiaPersonas home page",
                Open.browserOn().the(Downloads.class));

    }
}
