package starter.ui;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class EnterFinanceYourDreamsKnowMore {
    // Cuando estén en la URL ingresas a finanza tus sueños “SABER MÁS”//
    public static Target KnowMore_Button = Target.the(" ingresas a finanza tus sueños 'SABER MÁS'")
            .located(By.xpath("//*[@id=\"home-conoce-mas-productos\"]/div/div[2]/div[1]/div/div[2]/span/a"));
    //Clic en vehículos //
    public static Target Vehicles_Flap = Target.the("Solapa de Vehículos")
            .located(By.xpath("//*[@id=\"tab-categoria-vehiculo\"]"));
    // Clic en el simulador de crédito de moto de alto cilindraje //
    public static Target High_Cylinder_Motorcycle_Credit_Simulator = Target.the("Créditos Para Motos: Crédito para Moto de Alto Cilindraje")
            .located(By.xpath("//*[@id=\"creditos\"]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/a[1]"));
    // ¿Qué quieres comprar con este crédito? Seleccionar la opción: Motos
    public static Target Moto_Option = Target.the("¿Qué quieres comprar con este crédito? Seleccionar la opción: 'Motos'")
            .located(By.xpath("//*[@id=\"vehicleform\"]/div[1]/div/div/form/div/div/div/div[1]/div[2]/div/select"));
    // ¿Cuánto quieres que te prestemos? //
    public static Target Loan_Value = Target.the("¿Cuánto quieres que te prestemos? Seleccionar un valor en pesos colombianos: $ 19,350,355.00")
            .located(By.xpath("//*[@id=\"vehicleform\"]/div[1]/div/div/form/div/div/div/div[2]/div[2]/input"));
    //¿Cuántas Cuotas Quieres Pagar tu Crédito? Seleccionar: 48//
    public static Target loan_Installments = Target.the("¿Cuántas Cuotas Quieres Pagar tu Crédito? Seleccionar opción: 3, es decir, 48 cuotas")
            .located(By.xpath("//*[@id=\"vehicleform\"]/div[1]/div/div/form/div/div/div/div[3]/div[2]/div/select/option[3]"));
    // Seleccionar Botón: Simular Tu Crédito //
    public static Target Button_Submit = Target.the("Seleccionar botón: 'Simular Tú Crédito'")
            .located(By.xpath("//*[@id=\"btnSubmit\"]"));
    // Ver resultados 'Cuota Mensual'//
    public static Target MonthlyFee = Target.the("Verificar los valores de salida: 'Cuota Mensual'")
            .located(By.xpath("//*[@id=\"plans\"]/div/div[1]/div[2]/div[2]/p/strong"));
    // Ver resultado 'Seguro de Vida'//
    public static Target Life_Insurance = Target.the("Verificar los valores de salida: 'Seguro Vida'")
            .located(By.xpath("//*[@id=\"plans\"]/div/div[1]/div[3]/div[2]/p/strong"));
    // Ver resultado 'Total' //
    public static Target Total = Target.the("Verificar los valores de salida: 'Total'")
            .located(By.xpath("//*[@id=\"plans\"]/div/div[1]/div[4]/div[2]/p/strong"));
}
