package starter.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.waits.WaitUntil;
import starter.ui.EnterFinanceYourDreamsKnowMore;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public abstract class VehicleCreditSelection implements Task {
    //Método para seleccionar en finanza tus sueños “SABER MÁS” invocando el constructor se ejecuta de manera implicita cuando se ejecuta el proyecto.
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitUntil.the(EnterFinanceYourDreamsKnowMore.KnowMore_Button, isVisible()).forNoMoreThan(10).seconds(),
                Click.on(EnterFinanceYourDreamsKnowMore.KnowMore_Button),
                Click.on(EnterFinanceYourDreamsKnowMore.Vehicles_Flap),
                Click.on(EnterFinanceYourDreamsKnowMore.High_Cylinder_Motorcycle_Credit_Simulator)
        );
    }
}







