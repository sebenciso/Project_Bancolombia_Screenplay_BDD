package starter.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import starter.ui.EnterFinanceYourDreamsKnowMore;

public class NavigateToQuestions implements Question {

    //¿Cuál es el estilo CSS o XPathSelector con el nombre que se obtiene del botón 'Solapa de Vehículos'?
    @Override
    public String answeredBy(Actor actor) {
        return EnterFinanceYourDreamsKnowMore.Vehicles_Flap.getCssOrXPathSelector();
    }

}
