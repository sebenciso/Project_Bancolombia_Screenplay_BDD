package starter.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import starter.ui.EnterFinanceYourDreamsKnowMore;

public class SaberMasQuestions implements Question {

    //¿Cuál es el nombre que se obtiene ingresa a fianza tus sueños con el botón 'SABER MÁS'?
    @Override
    public String answeredBy(Actor actor) {
        return EnterFinanceYourDreamsKnowMore.KnowMore_Button.getName();
    }
}
