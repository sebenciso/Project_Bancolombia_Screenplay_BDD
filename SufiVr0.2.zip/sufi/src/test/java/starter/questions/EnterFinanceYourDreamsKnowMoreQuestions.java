package starter.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import starter.ui.EnterFinanceYourDreamsKnowMore;

public class EnterFinanceYourDreamsKnowMoreQuestions implements Question {

    //¿Cuál es el nombre que se obtiene del botón simulador?
    @Override
    public String answeredBy(Actor actor) {
        return EnterFinanceYourDreamsKnowMore.Button_Submit.getName();
    }
}
