package starter.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import starter.ui.EnterFinanceYourDreamsKnowMore;

public class BancolombiaHomePageQuestions implements Question {

    //¿Cuál es el nombre que se obtiene del Título: ingresa a finanza tus sueños 'SABER MÁS'?
    @Override
    public String answeredBy(Actor actor) {
        return EnterFinanceYourDreamsKnowMore.KnowMore_Button.resolveFor(actor).getText();
    }
}
