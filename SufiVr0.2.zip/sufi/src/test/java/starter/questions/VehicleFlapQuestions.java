package starter.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import starter.ui.EnterFinanceYourDreamsKnowMore;

public class VehicleFlapQuestions implements Question {

          //¿Cuál es el nombre que se obtiene del botón 'Solapa Vehículos'?
        @Override
        public String answeredBy(Actor actor) {
            return EnterFinanceYourDreamsKnowMore.Vehicles_Flap.getName();
        }
    }

