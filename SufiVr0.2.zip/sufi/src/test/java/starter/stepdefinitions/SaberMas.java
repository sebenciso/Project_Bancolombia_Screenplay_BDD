package starter.stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class SaberMas {

    @Before
    public void setTheStage ( ) {
        OnStage.setTheStage (new OnlineCast ());
    }

    @Given ("^Yo estoy en la URL*. ingresa a SABER MÁS$")
    public void yoEstoyEnLaURLIngresaASABERMÁS ( ) {

    }

    @When ("Yo puedo visualizar los resultados:\\*.,\\*.,\\*.")
    public void yoPuedoVisualizarLosResultados ( ) {
        theActorInTheSpotlight ().attemptsTo ();
    }

    @And ("^Yo doy click en el botón <SABER_MÁS>$")
    public void click_SABERMAS ( ) {
        theActorInTheSpotlight ().attemptsTo ();
    }
    //ValidarSimularTuCreditoSatisfactoriamente
    @When ("Yo doy click en la solapa Vehículo$")
    public void click_Vehiculo ( ) {
        theActorInTheSpotlight ().attemptsTo ();
    }

    @But ("^Yo doy click en la SIMULAR Crédito para motos de alto cilindraje$")
    public void click_SIMULAR ( ) {
        theActorInTheSpotlight ().attemptsTo ();
    }

    @Then ("^Yo puedo visualizar los resultados:(*.),(*.),(*.)$")
    public void Should_See_The_Search_Results ( ) {
        String EXPECTED_RESULTS_CUOTA = "Cuota Mensual";
        String EXPECTED_RESULTS_VIDA = "Seguro Vida";
        String EXPECTED_RESULTS_TOTAL = "Total";

        theActorInTheSpotlight ().attemptsTo ();
    }

    @And ("^Yo puedo descargar en archivo plano o Excel los resultados$")
    public void Should_See_The_Download_Results ( ) {
        theActorInTheSpotlight ().attemptsTo ();
    }


}


